<?php
define('DDBWP_FRAMWORK_CHANGE_LOG_PATH','http://ddb_wp.com/updates/change_log.txt');
define('DDBWP_FRAMWORK_ZIP_FOLDER_PATH','http://ddb_wp.com/updates/framework.zip');
define('DDBWP_FRAMWORK_CURRENT_VERSION','1.0.2');
define('DDB_FRAMEWORK_FOLDER_PATH',DDB_ADMIN_FOLDER_PATH);

if(file_exists(DDB_ADMIN_FOLDER_PATH . 'constants.php')){
include_once(DDB_ADMIN_FOLDER_PATH.'constants.php');  //ALL CONSTANTS FILE INTEGRATOR
}

include_once(DDB_ADMIN_FOLDER_PATH.'functions/custom_functions.php');//die('I am in Admin');
include_once(DDB_ADMIN_FOLDER_PATH.'functions/hooks.php');
include_once(DDB_ADMIN_FOLDER_PATH.'functions/tpl_control.php');
include_once (DDB_ADMIN_FOLDER_PATH . 'breadcrumbs/yoast-canonical.php'); //BREAD CRUMS RELATED FILE FOR WP-ADMIN SETTINGS
include_once (DDB_ADMIN_FOLDER_PATH . 'breadcrumbs/yoast-breadcrumbs.php'); //BREAD CRUMS RELATED FILE FOR FRONT END


if(is_wp_admin())
{
	include_once(DDB_ADMIN_FOLDER_PATH.'admin_menu.php');
	if((strtolower(get_option('ddbwpthemes_use_third_party_data'))=='no' || !get_option('ddbwpthemes_use_third_party_data')) && (strtolower(get_option('pttheme_seo_hide_fields'))=='no' || !get_option('pttheme_seo_hide_fields')))
	{
		include_once(DDB_ADMIN_FOLDER_PATH.'seo_settings.php');
	}
	if(file_exists(DDB_ADMIN_FOLDER_PATH . 'theme_options/option_settings.php'))
	{
		include_once(DDB_ADMIN_FOLDER_PATH . 'theme_options/option_settings.php');
	}
	
	if(file_exists(DDB_ADMIN_FOLDER_PATH . 'theme_options/functions/functions.load.php'))
	{
		include_once(DDB_ADMIN_FOLDER_PATH.'theme_options/functions/functions.load.php');
	}
}
?>