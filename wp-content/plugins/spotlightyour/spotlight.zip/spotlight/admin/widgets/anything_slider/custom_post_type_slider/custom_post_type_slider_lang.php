<?php
define('CUSTOM_POST_TYPE2','slider');
define('CUSTOM_CATEGORY_TYPE2','scategory');
define('CUSTOM_TAG_TYPE2','stags');

define('CUSTOM_MENU_TITLE2',__('Slider','ddb_wp'));
define('CUSTOM_MENU_NAME2',__('Slider','ddb_wp'));
define('CUSTOM_MENU_SIGULAR_NAME2',__('Slider','ddb_wp'));
define('CUSTOM_MENU_ADD_NEW2',__('Add Post','ddb_wp'));
define('CUSTOM_MENU_ADD_NEW_ITEM2',__('Add New Post','ddb_wp'));
define('CUSTOM_MENU_EDIT2',__('Edit','ddb_wp'));
define('CUSTOM_MENU_EDIT_ITEM2',__('Edit Post','ddb_wp'));
define('CUSTOM_MENU_NEW2',__('New Post','ddb_wp'));
define('CUSTOM_MENU_VIEW2',__('View Post','ddb_wp'));
define('CUSTOM_MENU_SEARCH2',__('Search Post','ddb_wp'));
define('CUSTOM_MENU_NOT_FOUND2',__('No Post found','ddb_wp'));
define('CUSTOM_MENU_NOT_FOUND_TRASH2',__('No Post found in trash','ddb_wp'));

define('CUSTOM_MENU_CAT_LABEL2',__('Slider Cities','ddb_wp'));
define('CUSTOM_MENU_CAT_TITLE2',__('Slider Cities','ddb_wp'));
define('CUSTOM_MENU_SIGULAR_CAT2',__('City','ddb_wp'));
define('CUSTOM_MENU_CAT_SEARCH2',__('Search City','ddb_wp'));
define('CUSTOM_MENU_CAT_POPULAR2',__('Popular Cities','ddb_wp'));
define('CUSTOM_MENU_CAT_ALL2',__('All Cities','ddb_wp'));
define('CUSTOM_MENU_CAT_PARENT2',__('Parent City','ddb_wp'));
define('CUSTOM_MENU_CAT_PARENT_COL2',__('Parent City:','ddb_wp'));
define('CUSTOM_MENU_CAT_EDIT2',__('Edit City','ddb_wp'));
define('CUSTOM_MENU_CAT_UPDATE2',__('Update City','ddb_wp'));
define('CUSTOM_MENU_CAT_ADDNEW2',__('Add New City','ddb_wp'));
define('CUSTOM_MENU_CAT_NEW_NAME2',__('New City Name','ddb_wp'));

define('CUSTOM_MENU_TAG_LABEL2',__('Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_TITLE2',__('Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_NAME2',__('Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_SEARCH2',__('Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_POPULAR2',__('Popular Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_ALL2',__('All Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_PARENT2',__('Parent Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_PARENT_COL2',__('Parent Slider Tags:','ddb_wp'));
define('CUSTOM_MENU_TAG_EDIT2',__('Edit Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_UPDATE2',__('Update Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_ADD_NEW2',__('Add New Slider Tags','ddb_wp'));
define('CUSTOM_MENU_TAG_NEW_ADD2',__('New Slider Tags Name','ddb_wp'));
?>