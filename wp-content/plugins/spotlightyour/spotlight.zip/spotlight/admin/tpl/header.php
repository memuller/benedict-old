<div id="framework_wrap" class="wrap">	
	<div id="header">
		<h1>ddb_wp</h1>   
		<div class="button_bar" style="width:50%"></div>  
 	</div>  
	<div id="content_wrap">
	