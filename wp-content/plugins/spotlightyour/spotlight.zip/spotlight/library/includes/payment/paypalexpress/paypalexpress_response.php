<?php 
	die('I m here');
?>