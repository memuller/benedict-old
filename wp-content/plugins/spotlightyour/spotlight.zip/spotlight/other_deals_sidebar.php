<div id="sidebar">
    <?php if ( is_active_sidebar( 'deals-right-sidebar' ) ) : ?>
		<?php dynamic_sidebar( 'deals-right-sidebar' ); ?>
	<?php endif; ?>
</div>  